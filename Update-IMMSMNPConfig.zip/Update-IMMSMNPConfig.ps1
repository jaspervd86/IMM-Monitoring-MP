﻿#Read all Lenovo hosts
param($ServerPath,$CommunityString,$UserName,$CompanyName,$MGIP1,$MGIP2)
$Servers = get-content -path $ServerPath

$SSHpass = Read-Host 'What is your SSH password?' -AsSecureString




    #SNMP Commands
foreach ($Server in $Servers)
{
    New-SshSession -ComputerName $Server -Username $UserName -Password $([Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SSHpass)))
    [string]$CommandSNMPConfig = "snmp -a on -a3 on -l $Server -cn $CompanyName -c1 $CommunityString -c1i1 $MGIP1 -c1i2 $MGIP2 -ca1 get -ca2 get -ca3 get"
    Invoke-SshCommand -ComputerName $Server -Quiet -Command $CommandSNMPConfig
    Invoke-SshCommand -ComputerName $Server -Quiet -Command 'snmpalerts -status on -crt all -crten enabled -wrn all -wrnen enabled -sys all -sysen enabled'
    Remove-SshSession -ComputerName $Server
    Write-Host "SNMP has been configured on $Server"
}
